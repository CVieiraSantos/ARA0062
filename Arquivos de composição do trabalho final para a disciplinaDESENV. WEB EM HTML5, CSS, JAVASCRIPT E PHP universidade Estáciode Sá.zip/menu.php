<?php
session_start();
if (! isset($_SESSION["autenticacao"])) { 
    
    
    echo '<script>
    window.location.replace("https://cadu-vieira-santos.000webhostapp.com/index.html");
    </script>
    ';
    
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    
    <head>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />
</head>

    <title>Menu</title>
  </head>
  <body style="background-color:lightgray">
    <h1 class="animate__animated animate__bounce" style=color:red>Bem-vindo ao nosso sistema</h1>
<hr>    
    
    <ul class="navbar navbar-dark bg-dark">
      <li class="nav-item">
        <a class="nav-link active" href="usuario/consultaUsuario.php">Cadastro de usuários</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="usuario/alterarUsuario.php">Alterar usuários</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="usuario/excluirUsuario.php">Excluir usuários</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="usuario/incluirUsuario.php">Incluir usuários</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="usuario/salvar.php">Salvar usuários</a>
      </li>
      
    </ul>
    <br>
    
    <!--<img src="https://www.oversodoinverso.com.br/wp-content/uploads/2015/11/tigre.jpg" alt="Um animal muito feroz" width="500" height="400" 
    class="animate__animated animate__lightSpeedInRight">
    
    
    <img src="https://i.ytimg.com/vi/VddK-Mv0Emo/maxresdefault.jpg" alt="Gato manhoso" width="500" height="400" 
    class="animate__animated animate__lightSpeedInRight"> -->
    
   
   <div class="card-deck">
  <div class="card">
    <img src="https://www.oversodoinverso.com.br/wp-content/uploads/2015/11/tigre.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Tigre raivoso</h5>
      <p class="card-text">Cuidado, ou o tigre te pega..</p>
      <p class="card-text"><small class="text-muted">Vamos grande tigre!</small></p>
    </div>
  </div>
  <div class="card">
    <img src="https://i.ytimg.com/vi/VddK-Mv0Emo/maxresdefault.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Gato manhoso</h5>
      <p class="card-text">Este gato é a cara da preguiça.</p>
      <p class="card-text"><small class="text-muted">Gostaria de ter uma jóia rara desta?</small></p>
    </div>
  </div>
  <div class="card">
    <img src="https://gcpstorage.caxias.rs.gov.br/images/2018/06/d654a249-9715-444a-af77-fbbaede6dc60_1200.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Curuja sábia</h5>
      <p class="card-text">Na curuja está contida a grande sabedoria e malandragem.</p>
      <p class="card-text"><small class="text-muted">Que possamos aprender com ela.</small></p>
    </div>
  </div>
</div>
   
   
   
   
   
   


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
  </body>
</html>